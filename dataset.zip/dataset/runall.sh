cd stage1
python math1.py
cd ../stage2
python math1.py
python math2.py
cd ..
