from datasets import load_dataset

# 加载数据集（自动识别train split）
dataset = load_dataset("PrimeIntellect/NuminaMath-QwQ-CoT-5M", split="train")

# 打乱数据顺序（不设种子以获得随机性）
shuffled = dataset.shuffle().select(800000)

# 字段重命名与列过滤
processed = shuffled.map(
    lambda x: {
        "problem": x["prompt"],    # 原始提示字段
        "solution": x["response"]  # 原始响应字段
    },
    remove_columns=shuffled.column_names  # 删除所有原始列
)

# 保存为JSON Lines（自动处理大文件分块）
processed.to_json(
    "3.jsonl",
    num_proc=8,          # 推荐设置为CPU物理核心数
    force_ascii=False    # 保留数学符号和代码字符
)