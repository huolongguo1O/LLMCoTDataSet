import json
from tqdm import tqdm  # 导入 tqdm 用于显示进度条

def load_jsonl(file_path):
    """加载 JSONL 文件并返回数据列表"""
    data = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in tqdm(f, desc=f"Loading {file_path}", unit="lines"):
            data.append(json.loads(line))
    return data

def save_jsonl(data, file_path):
    """将数据保存为 JSONL 文件"""
    with open(file_path, 'w', encoding='utf-8') as f:
        for item in tqdm(data, desc=f"Saving to {file_path}", unit="lines"):
            # 构造模板字符串
            text = f"User: {item['problem']}\n\nAssistant: {item['solution']}"
            # 写入文件
            f.write(json.dumps({'text': text}, ensure_ascii=False) + '\n')

def main():
    # 加载三个 JSONL 文件
    file_paths = ['math1/1.jsonl', 'math2/2.jsonl', 'math2/3.jsonl']
    all_data = []
    for file_path in file_paths:
        all_data.extend(load_jsonl(file_path))

    # 保存合并后的数据到 all.jsonl
    save_jsonl(all_data, 'all.jsonl')

if __name__ == "__main__":
    main()