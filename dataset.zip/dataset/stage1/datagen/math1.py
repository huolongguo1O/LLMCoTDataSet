from datasets import load_dataset

# 加载训练集
dataset = load_dataset("AI-MO/NuminaMath-CoT", split="train")

# 打乱数据顺序
shuffled_dataset = dataset.shuffle()

# 提取problem和solution两列
selected_dataset = shuffled_dataset.select_columns(["problem", "solution"])

# 使用多进程保存为JSON文件（num_proc设置为CPU核心数）
selected_dataset.to_json("1.json", num_proc=8)